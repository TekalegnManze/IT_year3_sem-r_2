﻿namespace KiddieCare
{
    partial class maintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ssss = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnDelRooms = new System.Windows.Forms.Button();
            this.btnAddRoom = new System.Windows.Forms.Button();
            this.listRoom = new System.Windows.Forms.ListView();
            this.txtRoom = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnDelGradeLvl = new System.Windows.Forms.Button();
            this.txtGradeLvl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAddLvl = new System.Windows.Forms.Button();
            this.listGradeLvl = new System.Windows.Forms.ListView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cboTime = new System.Windows.Forms.ComboBox();
            this.cmbGradeLevel = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbRoom = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.listPM = new System.Windows.Forms.ListView();
            this.txtPM = new System.Windows.Forms.TextBox();
            this.cmbSession = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCapacity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnTsched = new System.Windows.Forms.Button();
            this.listAM = new System.Windows.Forms.ListView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.Clear = new System.Windows.Forms.Button();
            this.btnUpdateMainten = new System.Windows.Forms.Button();
            this.btnSaveMainten = new System.Windows.Forms.Button();
            this.txtFifth = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFourth = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtThird = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSecond = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDown = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTuition = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.listView3 = new System.Windows.Forms.ListView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.cmbDayPart = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txtTo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtFrom = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.cmbParticular = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.ssss.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // ssss
            // 
            this.ssss.Controls.Add(this.tabPage1);
            this.ssss.Controls.Add(this.tabPage2);
            this.ssss.Controls.Add(this.tabPage3);
            this.ssss.Controls.Add(this.tabPage4);
            this.ssss.Controls.Add(this.tabPage5);
            this.ssss.Controls.Add(this.tabPage6);
            this.ssss.Font = new System.Drawing.Font("Century Gothic", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssss.Location = new System.Drawing.Point(12, 12);
            this.ssss.Name = "ssss";
            this.ssss.SelectedIndex = 0;
            this.ssss.Size = new System.Drawing.Size(616, 531);
            this.ssss.TabIndex = 1;
            this.ssss.SelectedIndexChanged += new System.EventHandler(this.listNursery_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.HotPink;
            this.tabPage1.Controls.Add(this.btnDelRooms);
            this.tabPage1.Controls.Add(this.btnAddRoom);
            this.tabPage1.Controls.Add(this.listRoom);
            this.tabPage1.Controls.Add(this.txtRoom);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 30);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(608, 497);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Rooms";
            // 
            // btnDelRooms
            // 
            this.btnDelRooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelRooms.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDelRooms.Location = new System.Drawing.Point(327, 34);
            this.btnDelRooms.Name = "btnDelRooms";
            this.btnDelRooms.Size = new System.Drawing.Size(82, 36);
            this.btnDelRooms.TabIndex = 115;
            this.btnDelRooms.Text = "Delete";
            this.btnDelRooms.UseVisualStyleBackColor = true;
            this.btnDelRooms.Click += new System.EventHandler(this.btnDelRooms_Click);
            // 
            // btnAddRoom
            // 
            this.btnAddRoom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddRoom.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddRoom.Location = new System.Drawing.Point(420, 34);
            this.btnAddRoom.Name = "btnAddRoom";
            this.btnAddRoom.Size = new System.Drawing.Size(83, 36);
            this.btnAddRoom.TabIndex = 112;
            this.btnAddRoom.Text = "Ok";
            this.btnAddRoom.UseVisualStyleBackColor = true;
            this.btnAddRoom.Click += new System.EventHandler(this.btnAddRoom_Click);
            // 
            // listRoom
            // 
            this.listRoom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listRoom.FullRowSelect = true;
            this.listRoom.GridLines = true;
            this.listRoom.Location = new System.Drawing.Point(23, 86);
            this.listRoom.Name = "listRoom";
            this.listRoom.Size = new System.Drawing.Size(546, 405);
            this.listRoom.TabIndex = 109;
            this.listRoom.UseCompatibleStateImageBehavior = false;
            this.listRoom.View = System.Windows.Forms.View.Details;
            this.listRoom.SelectedIndexChanged += new System.EventHandler(this.listRoom_SelectedIndexChanged);
            // 
            // txtRoom
            // 
            this.txtRoom.Location = new System.Drawing.Point(23, 43);
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Size = new System.Drawing.Size(217, 27);
            this.txtRoom.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(19, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Room";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.HotPink;
            this.tabPage2.Controls.Add(this.btnDelGradeLvl);
            this.tabPage2.Controls.Add(this.txtGradeLvl);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.btnAddLvl);
            this.tabPage2.Controls.Add(this.listGradeLvl);
            this.tabPage2.Location = new System.Drawing.Point(4, 30);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(608, 497);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Grade level";
            // 
            // btnDelGradeLvl
            // 
            this.btnDelGradeLvl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelGradeLvl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDelGradeLvl.Location = new System.Drawing.Point(331, 35);
            this.btnDelGradeLvl.Name = "btnDelGradeLvl";
            this.btnDelGradeLvl.Size = new System.Drawing.Size(78, 35);
            this.btnDelGradeLvl.TabIndex = 114;
            this.btnDelGradeLvl.Text = "Delete";
            this.btnDelGradeLvl.UseVisualStyleBackColor = true;
            // 
            // txtGradeLvl
            // 
            this.txtGradeLvl.Location = new System.Drawing.Point(23, 42);
            this.txtGradeLvl.Name = "txtGradeLvl";
            this.txtGradeLvl.Size = new System.Drawing.Size(217, 28);
            this.txtGradeLvl.TabIndex = 113;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(19, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 112;
            this.label2.Text = "Grade level";
            // 
            // btnAddLvl
            // 
            this.btnAddLvl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddLvl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddLvl.Location = new System.Drawing.Point(422, 35);
            this.btnAddLvl.Name = "btnAddLvl";
            this.btnAddLvl.Size = new System.Drawing.Size(78, 35);
            this.btnAddLvl.TabIndex = 111;
            this.btnAddLvl.Text = "Ok";
            this.btnAddLvl.UseVisualStyleBackColor = true;
            this.btnAddLvl.Click += new System.EventHandler(this.btnAddLvl_Click);
            // 
            // listGradeLvl
            // 
            this.listGradeLvl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listGradeLvl.FullRowSelect = true;
            this.listGradeLvl.GridLines = true;
            this.listGradeLvl.Location = new System.Drawing.Point(0, 92);
            this.listGradeLvl.Name = "listGradeLvl";
            this.listGradeLvl.Size = new System.Drawing.Size(546, 405);
            this.listGradeLvl.TabIndex = 110;
            this.listGradeLvl.UseCompatibleStateImageBehavior = false;
            this.listGradeLvl.View = System.Windows.Forms.View.Details;
            this.listGradeLvl.SelectedIndexChanged += new System.EventHandler(this.listGradeLvl_SelectedIndexChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.HotPink;
            this.tabPage3.Controls.Add(this.cboTime);
            this.tabPage3.Controls.Add(this.cmbGradeLevel);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.cmbRoom);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.listPM);
            this.tabPage3.Controls.Add(this.txtPM);
            this.tabPage3.Controls.Add(this.cmbSession);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.txtCapacity);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.txtAM);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.btnTsched);
            this.tabPage3.Controls.Add(this.listAM);
            this.tabPage3.Location = new System.Drawing.Point(4, 30);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(608, 497);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Time schedule";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // cboTime
            // 
            this.cboTime.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTime.FormattingEnabled = true;
            this.cboTime.Location = new System.Drawing.Point(165, 48);
            this.cboTime.Name = "cboTime";
            this.cboTime.Size = new System.Drawing.Size(217, 29);
            this.cboTime.TabIndex = 199;
            this.cboTime.SelectedIndexChanged += new System.EventHandler(this.cboTime_SelectedIndexChanged);
            // 
            // cmbGradeLevel
            // 
            this.cmbGradeLevel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGradeLevel.FormattingEnabled = true;
            this.cmbGradeLevel.Location = new System.Drawing.Point(165, 152);
            this.cmbGradeLevel.Name = "cmbGradeLevel";
            this.cmbGradeLevel.Size = new System.Drawing.Size(217, 29);
            this.cmbGradeLevel.TabIndex = 198;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(25, 157);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 19);
            this.label12.TabIndex = 197;
            this.label12.Text = "Grade Level";
            // 
            // cmbRoom
            // 
            this.cmbRoom.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRoom.FormattingEnabled = true;
            this.cmbRoom.Location = new System.Drawing.Point(165, 117);
            this.cmbRoom.Name = "cmbRoom";
            this.cmbRoom.Size = new System.Drawing.Size(217, 29);
            this.cmbRoom.TabIndex = 196;
            this.cmbRoom.SelectedIndexChanged += new System.EventHandler(this.cmbRoom_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(25, 122);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 19);
            this.label11.TabIndex = 195;
            this.label11.Text = "Room";
            // 
            // listPM
            // 
            this.listPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listPM.FullRowSelect = true;
            this.listPM.GridLines = true;
            this.listPM.Location = new System.Drawing.Point(274, 206);
            this.listPM.Name = "listPM";
            this.listPM.Size = new System.Drawing.Size(271, 291);
            this.listPM.TabIndex = 194;
            this.listPM.UseCompatibleStateImageBehavior = false;
            this.listPM.View = System.Windows.Forms.View.Details;
            // 
            // txtPM
            // 
            this.txtPM.Location = new System.Drawing.Point(434, 172);
            this.txtPM.Name = "txtPM";
            this.txtPM.Size = new System.Drawing.Size(105, 28);
            this.txtPM.TabIndex = 193;
            this.txtPM.Text = "00:00 PM";
            // 
            // cmbSession
            // 
            this.cmbSession.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSession.FormattingEnabled = true;
            this.cmbSession.Items.AddRange(new object[] {
            "Morning",
            "Afternoon"});
            this.cmbSession.Location = new System.Drawing.Point(165, 13);
            this.cmbSession.Name = "cmbSession";
            this.cmbSession.Size = new System.Drawing.Size(217, 29);
            this.cmbSession.TabIndex = 192;
            this.cmbSession.SelectedIndexChanged += new System.EventHandler(this.cmbSession_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(25, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 19);
            this.label13.TabIndex = 191;
            this.label13.Text = "Session";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(439, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 34);
            this.button1.TabIndex = 119;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // txtCapacity
            // 
            this.txtCapacity.Location = new System.Drawing.Point(165, 83);
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.Size = new System.Drawing.Size(217, 28);
            this.txtCapacity.TabIndex = 118;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(25, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 19);
            this.label4.TabIndex = 117;
            this.label4.Text = "Student Capacity";
            // 
            // txtAM
            // 
            this.txtAM.Location = new System.Drawing.Point(434, 138);
            this.txtAM.Name = "txtAM";
            this.txtAM.Size = new System.Drawing.Size(106, 28);
            this.txtAM.TabIndex = 116;
            this.txtAM.Text = "00:00 AM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(25, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 19);
            this.label3.TabIndex = 115;
            this.label3.Text = "Time Sched";
            // 
            // btnTsched
            // 
            this.btnTsched.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTsched.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnTsched.Location = new System.Drawing.Point(439, 62);
            this.btnTsched.Name = "btnTsched";
            this.btnTsched.Size = new System.Drawing.Size(85, 34);
            this.btnTsched.TabIndex = 114;
            this.btnTsched.Text = "Ok";
            this.btnTsched.UseVisualStyleBackColor = true;
            this.btnTsched.Click += new System.EventHandler(this.btnTsched_Click);
            // 
            // listAM
            // 
            this.listAM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listAM.FullRowSelect = true;
            this.listAM.GridLines = true;
            this.listAM.Location = new System.Drawing.Point(2, 206);
            this.listAM.Name = "listAM";
            this.listAM.Size = new System.Drawing.Size(271, 291);
            this.listAM.TabIndex = 110;
            this.listAM.UseCompatibleStateImageBehavior = false;
            this.listAM.View = System.Windows.Forms.View.Details;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.HotPink;
            this.tabPage4.Controls.Add(this.Clear);
            this.tabPage4.Controls.Add(this.btnUpdateMainten);
            this.tabPage4.Controls.Add(this.btnSaveMainten);
            this.tabPage4.Controls.Add(this.txtFifth);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.txtFourth);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.txtThird);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.txtSecond);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.txtDown);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.txtTuition);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.listView3);
            this.tabPage4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage4.Location = new System.Drawing.Point(4, 30);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(608, 497);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Payment";
            // 
            // Clear
            // 
            this.Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clear.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Clear.Location = new System.Drawing.Point(442, 156);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(85, 34);
            this.Clear.TabIndex = 126;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            // 
            // btnUpdateMainten
            // 
            this.btnUpdateMainten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateMainten.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnUpdateMainten.Location = new System.Drawing.Point(442, 93);
            this.btnUpdateMainten.Name = "btnUpdateMainten";
            this.btnUpdateMainten.Size = new System.Drawing.Size(85, 34);
            this.btnUpdateMainten.TabIndex = 125;
            this.btnUpdateMainten.Text = "Update";
            this.btnUpdateMainten.UseVisualStyleBackColor = true;
            this.btnUpdateMainten.Click += new System.EventHandler(this.btnUpdateMainten_Click);
            // 
            // btnSaveMainten
            // 
            this.btnSaveMainten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveMainten.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSaveMainten.Location = new System.Drawing.Point(442, 21);
            this.btnSaveMainten.Name = "btnSaveMainten";
            this.btnSaveMainten.Size = new System.Drawing.Size(85, 34);
            this.btnSaveMainten.TabIndex = 124;
            this.btnSaveMainten.Text = "Save";
            this.btnSaveMainten.UseVisualStyleBackColor = true;
            this.btnSaveMainten.Click += new System.EventHandler(this.btnSaveMainten_Click);
            // 
            // txtFifth
            // 
            this.txtFifth.BackColor = System.Drawing.Color.White;
            this.txtFifth.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFifth.Location = new System.Drawing.Point(164, 166);
            this.txtFifth.Name = "txtFifth";
            this.txtFifth.ReadOnly = true;
            this.txtFifth.Size = new System.Drawing.Size(204, 27);
            this.txtFifth.TabIndex = 123;
            this.txtFifth.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(33, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 19);
            this.label5.TabIndex = 122;
            this.label5.Text = "5thPayment";
            // 
            // txtFourth
            // 
            this.txtFourth.BackColor = System.Drawing.Color.White;
            this.txtFourth.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFourth.Location = new System.Drawing.Point(164, 137);
            this.txtFourth.Name = "txtFourth";
            this.txtFourth.ReadOnly = true;
            this.txtFourth.Size = new System.Drawing.Size(204, 27);
            this.txtFourth.TabIndex = 121;
            this.txtFourth.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(33, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 19);
            this.label6.TabIndex = 120;
            this.label6.Text = "4thPayment";
            // 
            // txtThird
            // 
            this.txtThird.BackColor = System.Drawing.Color.White;
            this.txtThird.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThird.Location = new System.Drawing.Point(164, 108);
            this.txtThird.Name = "txtThird";
            this.txtThird.ReadOnly = true;
            this.txtThird.Size = new System.Drawing.Size(204, 27);
            this.txtThird.TabIndex = 119;
            this.txtThird.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(33, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 19);
            this.label7.TabIndex = 118;
            this.label7.Text = "3rdPayment";
            // 
            // txtSecond
            // 
            this.txtSecond.BackColor = System.Drawing.Color.White;
            this.txtSecond.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecond.Location = new System.Drawing.Point(164, 79);
            this.txtSecond.Name = "txtSecond";
            this.txtSecond.ReadOnly = true;
            this.txtSecond.Size = new System.Drawing.Size(204, 27);
            this.txtSecond.TabIndex = 117;
            this.txtSecond.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(33, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 19);
            this.label8.TabIndex = 116;
            this.label8.Text = "2ndPayment";
            // 
            // txtDown
            // 
            this.txtDown.BackColor = System.Drawing.Color.White;
            this.txtDown.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDown.Location = new System.Drawing.Point(164, 50);
            this.txtDown.Name = "txtDown";
            this.txtDown.ReadOnly = true;
            this.txtDown.Size = new System.Drawing.Size(204, 27);
            this.txtDown.TabIndex = 115;
            this.txtDown.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(33, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 19);
            this.label9.TabIndex = 114;
            this.label9.Text = "Downpayment";
            // 
            // txtTuition
            // 
            this.txtTuition.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTuition.Location = new System.Drawing.Point(164, 21);
            this.txtTuition.Name = "txtTuition";
            this.txtTuition.Size = new System.Drawing.Size(204, 27);
            this.txtTuition.TabIndex = 113;
            this.txtTuition.Text = "0";
            this.txtTuition.TextChanged += new System.EventHandler(this.txtTuition_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(33, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 19);
            this.label10.TabIndex = 112;
            this.label10.Text = "Tuition Fee";
            // 
            // listView3
            // 
            this.listView3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView3.FullRowSelect = true;
            this.listView3.GridLines = true;
            this.listView3.Location = new System.Drawing.Point(0, 214);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(546, 283);
            this.listView3.TabIndex = 111;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.HotPink;
            this.tabPage5.Controls.Add(this.cmbDayPart);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.txtTo);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.txtFrom);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Location = new System.Drawing.Point(4, 30);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(608, 497);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Time";
            // 
            // cmbDayPart
            // 
            this.cmbDayPart.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDayPart.FormattingEnabled = true;
            this.cmbDayPart.Items.AddRange(new object[] {
            "Morning",
            "Afternoon"});
            this.cmbDayPart.Location = new System.Drawing.Point(68, 86);
            this.cmbDayPart.Name = "cmbDayPart";
            this.cmbDayPart.Size = new System.Drawing.Size(285, 29);
            this.cmbDayPart.TabIndex = 194;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(6, 91);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 19);
            this.label16.TabIndex = 193;
            this.label16.Text = "Session";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(68, 132);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 34);
            this.button2.TabIndex = 125;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtTo
            // 
            this.txtTo.Location = new System.Drawing.Point(228, 44);
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new System.Drawing.Size(125, 28);
            this.txtTo.TabIndex = 122;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(199, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 19);
            this.label15.TabIndex = 121;
            this.label15.Text = "To";
            // 
            // txtFrom
            // 
            this.txtFrom.Location = new System.Drawing.Point(68, 44);
            this.txtFrom.Name = "txtFrom";
            this.txtFrom.Size = new System.Drawing.Size(125, 28);
            this.txtFrom.TabIndex = 120;
            this.txtFrom.TextChanged += new System.EventHandler(this.txtFrom_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(6, 49);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 19);
            this.label14.TabIndex = 119;
            this.label14.Text = "From";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.HotPink;
            this.tabPage6.Controls.Add(this.button3);
            this.tabPage6.Controls.Add(this.dateTimePicker1);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.cmbParticular);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Location = new System.Drawing.Point(4, 30);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(608, 497);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Schedule Of Payment";
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.Location = new System.Drawing.Point(124, 102);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 34);
            this.button3.TabIndex = 199;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(124, 68);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(189, 28);
            this.dateTimePicker1.TabIndex = 198;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label18.Location = new System.Drawing.Point(23, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 19);
            this.label18.TabIndex = 197;
            this.label18.Text = "Due Date";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // cmbParticular
            // 
            this.cmbParticular.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbParticular.FormattingEnabled = true;
            this.cmbParticular.Items.AddRange(new object[] {
            "downpayment",
            "secondpayment",
            "thirdpayment",
            "fourthpayment",
            "fifthpayment"});
            this.cmbParticular.Location = new System.Drawing.Point(124, 28);
            this.cmbParticular.Name = "cmbParticular";
            this.cmbParticular.Size = new System.Drawing.Size(189, 29);
            this.cmbParticular.TabIndex = 196;
            this.cmbParticular.SelectedIndexChanged += new System.EventHandler(this.cmbParticular_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label17.Location = new System.Drawing.Point(23, 33);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 19);
            this.label17.TabIndex = 195;
            this.label17.Text = "Particular";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // maintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(640, 555);
            this.Controls.Add(this.ssss);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "maintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.maintenance_Load);
            this.ssss.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl ssss;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox txtRoom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listRoom;
        private System.Windows.Forms.Button btnDelRooms;
        private System.Windows.Forms.Button btnAddRoom;
        private System.Windows.Forms.Button btnDelGradeLvl;
        private System.Windows.Forms.TextBox txtGradeLvl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddLvl;
        private System.Windows.Forms.ListView listGradeLvl;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCapacity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnTsched;
        private System.Windows.Forms.ListView listAM;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button btnUpdateMainten;
        private System.Windows.Forms.Button btnSaveMainten;
        private System.Windows.Forms.TextBox txtFifth;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFourth;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtThird;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSecond;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDown;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTuition;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ComboBox cmbSession;
        internal System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtPM;
        private System.Windows.Forms.ListView listPM;
        private System.Windows.Forms.ComboBox cmbRoom;
        internal System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbGradeLevel;
        internal System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboTime;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox txtTo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtFrom;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbDayPart;
        internal System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ComboBox cmbParticular;
        internal System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        internal System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button3;
    }
}