﻿namespace KiddieCare
{
    partial class StatementOFAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StatementOFAccount));
            this.panel3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtPayable = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblSection = new System.Windows.Forms.Label();
            this.lblGradelvl = new System.Windows.Forms.Label();
            this.lblMTotal = new System.Windows.Forms.Label();
            this.lblMisc = new System.Windows.Forms.Label();
            this.lblMMisc = new System.Windows.Forms.Label();
            this.lblWMisc = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblMTuition = new System.Windows.Forms.Label();
            this.lblWTuition = new System.Windows.Forms.Label();
            this.lblWOthers = new System.Windows.Forms.Label();
            this.lblWTotal = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblLess = new System.Windows.Forms.Label();
            this.lblOthers = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblMOthers = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblMMiscTot = new System.Windows.Forms.Label();
            this.lblWMiscTot = new System.Windows.Forms.Label();
            this.lblMOthersTot = new System.Windows.Forms.Label();
            this.lblWOthersTot = new System.Windows.Forms.Label();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.lblPartcular = new System.Windows.Forms.Label();
            this.lblPace = new System.Windows.Forms.Label();
            this.lblPcs = new System.Windows.Forms.Label();
            this.lblPaceTotal = new System.Windows.Forms.Label();
            this.listahan = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel3.Controls.Add(this.label12);
            this.panel3.Location = new System.Drawing.Point(0, 117);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(707, 24);
            this.panel3.TabIndex = 186;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(282, 1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(172, 18);
            this.label12.TabIndex = 183;
            this.label12.Text = "Statement of Accounts";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 17);
            this.label1.TabIndex = 187;
            this.label1.Text = "Student ID         :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 17);
            this.label2.TabIndex = 188;
            this.label2.Text = "Student Name  :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 17);
            this.label3.TabIndex = 189;
            this.label3.Text = "Grade level       :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(12, 141);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(681, 25);
            this.panel1.TabIndex = 187;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(441, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(216, 16);
            this.label6.TabIndex = 190;
            this.label6.Text = "Whole Academic Year (10 mos) ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(295, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 185;
            this.label5.Text = "Monthly";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(42, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 16);
            this.label4.TabIndex = 184;
            this.label4.Text = "Description";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel2.Controls.Add(this.label7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(707, 34);
            this.panel2.TabIndex = 187;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(282, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(231, 18);
            this.label7.TabIndex = 183;
            this.label7.Text = "Christian Kiddie Star Academy";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label27.Location = new System.Drawing.Point(16, 668);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(389, 16);
            this.label27.TabIndex = 213;
            this.label27.Text = "Shortcut Key :  ESC to Exit | S to Search | P to Print Receipt | A to Save";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::KiddieCare.Properties.Resources.CKSA_logo;
            this.pictureBox1.Location = new System.Drawing.Point(599, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(78, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 190;
            this.pictureBox1.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape8,
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(707, 689);
            this.shapeContainer1.TabIndex = 191;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 14;
            this.lineShape8.X2 = 694;
            this.lineShape8.Y1 = 472;
            this.lineShape8.Y2 = 472;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 424;
            this.lineShape7.X2 = 609;
            this.lineShape7.Y1 = 398;
            this.lineShape7.Y2 = 398;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 66;
            this.lineShape6.X2 = 344;
            this.lineShape6.Y1 = 400;
            this.lineShape6.Y2 = 400;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 425;
            this.lineShape5.X2 = 607;
            this.lineShape5.Y1 = 281;
            this.lineShape5.Y2 = 281;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 67;
            this.lineShape4.X2 = 346;
            this.lineShape4.Y1 = 283;
            this.lineShape4.Y2 = 283;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 424;
            this.lineShape3.X2 = 424;
            this.lineShape3.Y1 = 164;
            this.lineShape3.Y2 = 432;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 235;
            this.lineShape2.X2 = 235;
            this.lineShape2.Y1 = 160;
            this.lineShape2.Y2 = 432;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 12;
            this.lineShape1.X2 = 692;
            this.lineShape1.Y1 = 630;
            this.lineShape1.Y2 = 630;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.Location = new System.Drawing.Point(12, 165);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(681, 267);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(21, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 16);
            this.label8.TabIndex = 192;
            this.label8.Text = "Tuition fee";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(21, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 193;
            this.label9.Text = "Other Fees";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(86, 436);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 194;
            this.label10.Text = "Total Fees";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(21, 452);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 17);
            this.label17.TabIndex = 200;
            this.label17.Text = "ADD:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(21, 477);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 16);
            this.label18.TabIndex = 201;
            this.label18.Text = "TOTAL FEES";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(22, 493);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 17);
            this.label19.TabIndex = 202;
            this.label19.Text = "Less payment";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(67, 284);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 16);
            this.label20.TabIndex = 203;
            this.label20.Text = "Subtotal";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(204, 513);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 16);
            this.label22.TabIndex = 209;
            this.label22.Text = "Particulars";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(28, 513);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(38, 16);
            this.label23.TabIndex = 210;
            this.label23.Text = "Date";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(440, 513);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 16);
            this.label24.TabIndex = 211;
            this.label24.Text = "Amount";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel4.Controls.Add(this.txtPayable);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Location = new System.Drawing.Point(11, 636);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(681, 29);
            this.panel4.TabIndex = 191;
            // 
            // txtPayable
            // 
            this.txtPayable.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayable.Location = new System.Drawing.Point(414, 4);
            this.txtPayable.Name = "txtPayable";
            this.txtPayable.Size = new System.Drawing.Size(231, 20);
            this.txtPayable.TabIndex = 244;
            this.txtPayable.Text = "0.00";
            this.txtPayable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtPayable.Click += new System.EventHandler(this.txtPayable_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(11, 7);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(183, 16);
            this.label28.TabIndex = 184;
            this.label28.Text = "TOTAL ACCOUNTS PAYABLE";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(142, 46);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(236, 16);
            this.lblName.TabIndex = 214;
            this.lblName.Text = "                                                         ";
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // lblSection
            // 
            this.lblSection.AutoSize = true;
            this.lblSection.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSection.Location = new System.Drawing.Point(142, 66);
            this.lblSection.Name = "lblSection";
            this.lblSection.Size = new System.Drawing.Size(196, 16);
            this.lblSection.TabIndex = 215;
            this.lblSection.Text = "                                               ";
            // 
            // lblGradelvl
            // 
            this.lblGradelvl.AutoSize = true;
            this.lblGradelvl.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGradelvl.Location = new System.Drawing.Point(142, 86);
            this.lblGradelvl.Name = "lblGradelvl";
            this.lblGradelvl.Size = new System.Drawing.Size(212, 16);
            this.lblGradelvl.TabIndex = 216;
            this.lblGradelvl.Text = "                                                   ";
            // 
            // lblMTotal
            // 
            this.lblMTotal.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMTotal.Location = new System.Drawing.Point(277, 434);
            this.lblMTotal.Name = "lblMTotal";
            this.lblMTotal.Size = new System.Drawing.Size(127, 20);
            this.lblMTotal.TabIndex = 220;
            this.lblMTotal.Text = "0.00";
            this.lblMTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMisc
            // 
            this.lblMisc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblMisc.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMisc.Location = new System.Drawing.Point(48, 215);
            this.lblMisc.Name = "lblMisc";
            this.lblMisc.Size = new System.Drawing.Size(171, 59);
            this.lblMisc.TabIndex = 228;
            // 
            // lblMMisc
            // 
            this.lblMMisc.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMMisc.Location = new System.Drawing.Point(350, 215);
            this.lblMMisc.Name = "lblMMisc";
            this.lblMMisc.Size = new System.Drawing.Size(64, 59);
            this.lblMMisc.TabIndex = 233;
            // 
            // lblWMisc
            // 
            this.lblWMisc.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWMisc.Location = new System.Drawing.Point(599, 215);
            this.lblWMisc.Name = "lblWMisc";
            this.lblWMisc.Size = new System.Drawing.Size(70, 59);
            this.lblWMisc.TabIndex = 235;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(22, 193);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(127, 16);
            this.label14.TabIndex = 237;
            this.label14.Text = "Miscellaneous Fee";
            // 
            // lblMTuition
            // 
            this.lblMTuition.AutoSize = true;
            this.lblMTuition.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMTuition.Location = new System.Drawing.Point(359, 177);
            this.lblMTuition.Name = "lblMTuition";
            this.lblMTuition.Size = new System.Drawing.Size(37, 20);
            this.lblMTuition.TabIndex = 238;
            this.lblMTuition.Text = "0.00";
            // 
            // lblWTuition
            // 
            this.lblWTuition.AutoSize = true;
            this.lblWTuition.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWTuition.Location = new System.Drawing.Point(619, 177);
            this.lblWTuition.Name = "lblWTuition";
            this.lblWTuition.Size = new System.Drawing.Size(37, 20);
            this.lblWTuition.TabIndex = 239;
            this.lblWTuition.Text = "0.00";
            // 
            // lblWOthers
            // 
            this.lblWOthers.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWOthers.Location = new System.Drawing.Point(565, 309);
            this.lblWOthers.Name = "lblWOthers";
            this.lblWOthers.Size = new System.Drawing.Size(104, 76);
            this.lblWOthers.TabIndex = 240;
            // 
            // lblWTotal
            // 
            this.lblWTotal.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWTotal.Location = new System.Drawing.Point(533, 434);
            this.lblWTotal.Name = "lblWTotal";
            this.lblWTotal.Size = new System.Drawing.Size(127, 20);
            this.lblWTotal.TabIndex = 241;
            this.lblWTotal.Text = "0.00";
            this.lblWTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotal
            // 
            this.lblTotal.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(532, 475);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(127, 20);
            this.lblTotal.TabIndex = 242;
            this.lblTotal.Text = "0.00";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLess
            // 
            this.lblLess.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLess.Location = new System.Drawing.Point(524, 607);
            this.lblLess.Name = "lblLess";
            this.lblLess.Size = new System.Drawing.Size(127, 20);
            this.lblLess.TabIndex = 243;
            this.lblLess.Text = "0.00";
            this.lblLess.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblLess.Click += new System.EventHandler(this.lblLess_Click);
            // 
            // lblOthers
            // 
            this.lblOthers.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOthers.Location = new System.Drawing.Point(61, 320);
            this.lblOthers.Name = "lblOthers";
            this.lblOthers.Size = new System.Drawing.Size(161, 71);
            this.lblOthers.TabIndex = 230;
            // 
            // lblDate
            // 
            this.lblDate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(61, 536);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(184, 84);
            this.lblDate.TabIndex = 244;
            this.lblDate.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // lblMOthers
            // 
            this.lblMOthers.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMOthers.Location = new System.Drawing.Point(334, 315);
            this.lblMOthers.Name = "lblMOthers";
            this.lblMOthers.Size = new System.Drawing.Size(79, 70);
            this.lblMOthers.TabIndex = 245;
            // 
            // lblAmount
            // 
            this.lblAmount.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.Location = new System.Drawing.Point(466, 537);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(161, 70);
            this.lblAmount.TabIndex = 246;
            this.lblAmount.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // lblMMiscTot
            // 
            this.lblMMiscTot.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMMiscTot.Location = new System.Drawing.Point(268, 284);
            this.lblMMiscTot.Name = "lblMMiscTot";
            this.lblMMiscTot.Size = new System.Drawing.Size(127, 20);
            this.lblMMiscTot.TabIndex = 247;
            this.lblMMiscTot.Text = "0.00";
            this.lblMMiscTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblWMiscTot
            // 
            this.lblWMiscTot.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWMiscTot.Location = new System.Drawing.Point(529, 284);
            this.lblWMiscTot.Name = "lblWMiscTot";
            this.lblWMiscTot.Size = new System.Drawing.Size(127, 20);
            this.lblWMiscTot.TabIndex = 248;
            this.lblWMiscTot.Text = "0.00";
            this.lblWMiscTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMOthersTot
            // 
            this.lblMOthersTot.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMOthersTot.Location = new System.Drawing.Point(277, 404);
            this.lblMOthersTot.Name = "lblMOthersTot";
            this.lblMOthersTot.Size = new System.Drawing.Size(127, 20);
            this.lblMOthersTot.TabIndex = 249;
            this.lblMOthersTot.Text = "0.00";
            this.lblMOthersTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblWOthersTot
            // 
            this.lblWOthersTot.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWOthersTot.Location = new System.Drawing.Point(529, 404);
            this.lblWOthersTot.Name = "lblWOthersTot";
            this.lblWOthersTot.Size = new System.Drawing.Size(127, 20);
            this.lblWOthersTot.TabIndex = 250;
            this.lblWOthersTot.Text = "0.00";
            this.lblWOthersTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // lblPartcular
            // 
            this.lblPartcular.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPartcular.Location = new System.Drawing.Point(278, 537);
            this.lblPartcular.Name = "lblPartcular";
            this.lblPartcular.Size = new System.Drawing.Size(144, 75);
            this.lblPartcular.TabIndex = 251;
            this.lblPartcular.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
            // 
            // lblPace
            // 
            this.lblPace.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPace.Location = new System.Drawing.Point(88, 453);
            this.lblPace.Name = "lblPace";
            this.lblPace.Size = new System.Drawing.Size(225, 17);
            this.lblPace.TabIndex = 252;
            // 
            // lblPcs
            // 
            this.lblPcs.AutoSize = true;
            this.lblPcs.Font = new System.Drawing.Font("Century Gothic", 10.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPcs.Location = new System.Drawing.Point(330, 450);
            this.lblPcs.Name = "lblPcs";
            this.lblPcs.Size = new System.Drawing.Size(41, 20);
            this.lblPcs.TabIndex = 253;
            this.lblPcs.Text = "        ";
            // 
            // lblPaceTotal
            // 
            this.lblPaceTotal.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaceTotal.Location = new System.Drawing.Point(533, 452);
            this.lblPaceTotal.Name = "lblPaceTotal";
            this.lblPaceTotal.Size = new System.Drawing.Size(127, 17);
            this.lblPaceTotal.TabIndex = 254;
            this.lblPaceTotal.Text = "0.00";
            this.lblPaceTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblPaceTotal.Click += new System.EventHandler(this.lblPaceTotal_Click);
            // 
            // listahan
            // 
            this.listahan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listahan.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listahan.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listahan.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listahan.Location = new System.Drawing.Point(24, 529);
            this.listahan.MultiSelect = false;
            this.listahan.Name = "listahan";
            this.listahan.Size = new System.Drawing.Size(659, 101);
            this.listahan.TabIndex = 255;
            this.listahan.UseCompatibleStateImageBehavior = false;
            this.listahan.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Date";
            this.columnHeader1.Width = 175;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Particular";
            this.columnHeader2.Width = 180;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Amount";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 180;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // StatementOFAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(707, 689);
            this.Controls.Add(this.lblLess);
            this.Controls.Add(this.listahan);
            this.Controls.Add(this.lblPaceTotal);
            this.Controls.Add(this.lblPcs);
            this.Controls.Add(this.lblPace);
            this.Controls.Add(this.lblPartcular);
            this.Controls.Add(this.lblWOthersTot);
            this.Controls.Add(this.lblMOthersTot);
            this.Controls.Add(this.lblWMiscTot);
            this.Controls.Add(this.lblMMiscTot);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.lblMOthers);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblWTotal);
            this.Controls.Add(this.lblWOthers);
            this.Controls.Add(this.lblWTuition);
            this.Controls.Add(this.lblMTuition);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblWMisc);
            this.Controls.Add(this.lblMMisc);
            this.Controls.Add(this.lblOthers);
            this.Controls.Add(this.lblMisc);
            this.Controls.Add(this.lblMTotal);
            this.Controls.Add(this.lblGradelvl);
            this.Controls.Add(this.lblSection);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "StatementOFAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StatementOFAccount";
            this.Load += new System.EventHandler(this.StatementOFAccount_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.StatementOFAccount_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.StatementOFAccount_KeyPress);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.StatementOFAccount_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.StatementOFAccount_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.StatementOFAccount_MouseUp);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label lblName;
        public System.Windows.Forms.Label lblSection;
        public System.Windows.Forms.Label lblGradelvl;
        private System.Windows.Forms.Label lblMTotal;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblMTuition;
        private System.Windows.Forms.Label lblWTuition;
        private System.Windows.Forms.Label lblWTotal;
        private System.Windows.Forms.Label lblTotal;
        public System.Windows.Forms.Label lblMisc;
        public System.Windows.Forms.Label lblMMisc;
        public System.Windows.Forms.Label lblWMisc;
        public System.Windows.Forms.Label lblWOthers;
        private System.Windows.Forms.Label txtPayable;
        private System.Windows.Forms.Label lblLess;
        public System.Windows.Forms.Label lblOthers;
        public System.Windows.Forms.Label lblMOthers;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblMMiscTot;
        private System.Windows.Forms.Label lblWMiscTot;
        private System.Windows.Forms.Label lblMOthersTot;
        private System.Windows.Forms.Label lblWOthersTot;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Label lblPartcular;
        public System.Windows.Forms.Label lblPace;
        private System.Windows.Forms.Label lblPcs;
        private System.Windows.Forms.Label lblPaceTotal;
        public System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.ListView listahan;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Timer timer1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}