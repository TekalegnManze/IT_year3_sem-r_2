﻿namespace KiddieCare
{


    public partial class DataSet1
    {
    }
}
namespace KiddieCare {
    
    
    public partial class DataSet1 {
    }
}
